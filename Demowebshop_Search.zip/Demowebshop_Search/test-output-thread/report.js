$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"e2c66e30-d352-4120-8519-766b23e4a8d2","feature":"Search Functionality","scenario":"Perform Search","start":1705560312452,"group":1,"content":"","tags":"","end":1705560430008,"className":"failed"},{"id":"c1de6b09-5fc1-4cd1-ba77-efe12e722fba","feature":"Search Functionality","scenario":"Handle Pop-up","start":1705560252901,"group":1,"content":"","tags":"","end":1705560312420,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[#1,main,5,main]"}]);
});