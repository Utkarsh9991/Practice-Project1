package testnglisteners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


public class CucumberExtentReportListener implements ITestListener {
    private ExtentReports extentReports;
    private ExtentTest extentTest;
    

    @Override
    public void onStart(ITestContext context) {
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter("target/SparkReport.html");
        extentReports = new ExtentReports();
        extentReports.attachReporter(sparkReporter);
        System.out.println("listener sparkkkkkk1");
    }

    @Override
    public void onTestStart(ITestResult result) {
        extentTest = extentReports.createTest(result.getMethod().getMethodName());
        System.out.println("listener sparkkkkkk12");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        extentTest.fail(result.getThrowable());
        System.out.println("listener sparkkkkkk123");
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        extentTest.pass("Test passed");
        System.out.println("listener sparkkkkkk1234");
    }

    @Override
    public void onFinish(ITestContext context) {
        extentReports.flush();
        System.out.println("listener sparkkkkkk123456");
    }
}


