package runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import testnglisteners.CucumberExtentReportListener;


import org.junit.runner.RunWith;
import org.testng.annotations.Listeners;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"C:\\Users\\utkar\\eclipse-workspace\\Demowebshop_Search\\src\\test\\java\\feature\\search.feature",
                    },
        glue = {"steps" },
        dryRun = false,
        plugin = {
            "pretty",
            "html:target/cucumberreport_search.html",
            "json:target/cucumber.json",
            "junit:target/xmlReport.xml",
            "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:\", \"timeline:test-output-thread/"
            
          
        },
        monochrome=true
)


@Listeners(CucumberExtentReportListener.class)
public class TestRunner {
	
}
